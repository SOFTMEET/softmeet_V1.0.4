import 'dart:developer';
import 'dart:io';
import 'package:bubble/bubble.dart';
import 'package:dialog_flowtter/dialog_flowtter.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:firebase_storage/firebase_storage.dart' as firebase_storage;
import 'package:path/path.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:path_provider/path_provider.dart';
import 'package:dio/dio.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:cr_file_saver/file_saver.dart';
import 'dart:math';


class chatbot_msg extends StatefulWidget {
  const chatbot_msg({Key? key}) : super(key: key);



  @override
  _chatbot_msgState createState() => _chatbot_msgState();

}

class _chatbot_msgState extends State<chatbot_msg> {
  FirebaseAuth? auth;
  User? user;
  String? subscriptionPlanPrice, userId, documentId;
  bool? isSubscribe;
  bool? pdfBtn=true;






  File? _cv;
  FilePickerResult? result;

  bool? getCV;   //if the getCv true then attachment becomes clickable the icon changes colors
  String pdfIntent="Click pdf button to upload your CV"; //dont temper with tis, unless u match with the response on dialogflow
  String uploadIntent="The email has been sent to your future employer"; //dont temper with tis unless you match the reponse
  String downloadIntent="Please enter work mail"; // dont temper with tis ''''''''''''''''''''''''''''''''''''''''''''''''
  late String email1='';
  late String email2='';
  final int sesId=generateRandomNumber();

  firebase_storage.FirebaseStorage storage =
      firebase_storage.FirebaseStorage.instance;

  FirebaseFirestore firestore = FirebaseFirestore.instance;


  void response(messageInsert) async {
    DialogAuthCredentials dialogAuthCredentials =
    await DialogAuthCredentials.fromFile('assets/chatservices.json');

    final DialogFlowtter dialogFlowtter =
    DialogFlowtter(credentials: dialogAuthCredentials, sessionId: '$sesId');

    final QueryInput queryInput = QueryInput(
      text: TextInput(
        text: messageInsert,
        languageCode: 'en',
      ),
    );



    DetectIntentResponse response = await dialogFlowtter.detectIntent(
      queryInput: queryInput,
    );

    if(response.message?.text?.text?[0]==pdfIntent) {
      getCV = true;

    }


    setState(() {
      messsages
          .insert(0, {"data": 0, "message": response.message?.text?.text?[0]});
    });
  }

  final messageInsert = TextEditingController();
  List<Map> messsages = [];

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      backgroundColor: Theme
          .of(context)
          .primaryColor,
      appBar: AppBar(

        backgroundColor: const Color(0xff0d1b4b),
        titleSpacing: 0.5,
        title: Row(
          children: [
            const CircleAvatar(

              backgroundImage: AssetImage('assets/robot.jpg'),
            ),
            const Padding(
              padding: EdgeInsets.only(left: 8.0),

              child: Text(
                'Create CV',

                style: TextStyle(
                  fontSize: 18,
                  height: 2.5,
                  //line height 200%, 1= 100%, were 0.9 = 90% of actual line height
                  color: Colors.white,
                  //font color

                  decorationThickness: 1.5, //decoration 'underline' thickness

                ),
              ),
            ),
          ],
        ),
        actions: [
          PopupMenuButton<String>(
            color: Colors.white,
            itemBuilder: (BuildContext context) {
              return [
                PopupMenuItem
                  (
                  onTap: () {showDialog(
                      context: context,builder: (context) {return Container(
                    child: AlertDialog(
                      title: Text("Info Coming soon!"),
                      actions: [
                        TextButton(onPressed: () {
                          Navigator.pop(context);
                        }, child: Text("OK"))
                      ],
                    ),
                  );}
                  ); },
                  value: "New group",
                  child: Text('Info'),
                ),
                PopupMenuItem(
                  onTap: () {showDialog(
                      context: context,builder: (context) {return Container(
                    child: AlertDialog(
                      title: Text("Please direct your queries to support@softmeet.co.za"),
                      actions: [
                        TextButton(onPressed: () {
                          Navigator.pop(context);
                        }, child: Text("OK"))
                      ],
                    ),
                  );}
                  ); },
                  value: "New group",
                  child: Text('Chat-bot Support'),
                ),
              ];
            },
          ),
          //IconButton(
          //icon: const Icon(Icons.more_vert),
          //onPressed: () {
          //print('Three Dot-Button Button');
          //}),
        ],
      ),

      body: SafeArea(

        child: Column(

          children: <Widget>[
            Flexible(
                child: ListView.builder(
                    reverse: true,
                    itemCount: messsages.length,
                    itemBuilder: (context, index) =>
                        chat(
                            messsages[index]["message"].toString(),
                            messsages[index]["data"]))
            ),
            const SizedBox(
              height: 10,

            ),

            ListTile(

              /*     leading: Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(250),
                ),
                child: IconButton(
                  onPressed: () {
                    print('ok');
                    showModalBottomSheet(context: context, builder: (builder)=>bottomIcons());
                  },
                  icon: const Icon(
                    Icons. attachment_outlined,
                    color: Colors.black,
                    size: 30,
                  ),
                ),
              ),  */

              title: Row(
                children: [

                  Expanded(
                    flex: 5,


                    child: Padding(
                      padding: const EdgeInsets.only(
                        bottom: 8,
                        right: 5,
                        left: 3,
                      ),

                      child: Container(
                        height: 40,
                        width: 2500,
                        //               color: Colors.orangeAccent,
                        decoration: const BoxDecoration(
                          borderRadius: BorderRadius.all(Radius.circular(100)),
                          color: Color.fromRGBO(220, 220, 220, 1),

                        ),
                        padding: const EdgeInsets.only(left: 2),

                        child: Center(
                          child: TextFormField(
                            controller: messageInsert,
                            onTap: () {
                              //        print("I'm here!!!");
                            },
                            textAlignVertical: TextAlignVertical.center,
                            keyboardType: TextInputType.multiline,
                            maxLines: null, // 5,
                            minLines: null, // 1,
                            expands: true,

                            decoration: InputDecoration(
                              /*                  prefixIcon: IconButton(
                                icon: const Icon(Icons.emoji_emotions),
                                onPressed: () {
                                  print(email1 +' email 1 emoji');
                                  print(email2 + ' email 2 emoji');

                                },
                              ), */
                              suffixIcon: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  IconButton(
                                      icon: const Icon(

                                        Icons.picture_as_pdf_outlined,),

                                      onPressed: () async {
                                        if (getCV == true) {
                                          cvFromGallery();


                                        }
                                      }),


                                  /*      IconButton(
                                    icon: const Icon(Icons.camera_alt),
                                    onPressed: () async {
                   //                   ini.sendEmail(email1,email2);

                                  /*    final materialBanner = MaterialBanner(
                                        /// need to set following properties for best effect of awesome_snackbar_content
                                        elevation: 0,
                                        backgroundColor: Colors.transparent,
                                        forceActionsBelow: false,

                                        content: AwesomeSnackbarContent(
                                          title: 'Oh Hey!!',
                                          message:
                                          'The email has been sent to your prospective employer, Thank your using Softmeet Chatbot!',

                                          /// change contentType to ContentType.success, ContentType.warning or ContentType.help for variants
                                          contentType: ContentType.success,
                                          // to configure for material banner
                                          inMaterialBanner: true,
                                        ),
                                        actions: const [SizedBox.shrink()],
                                      );

                                      ScaffoldMessenger.of(context)
                                        ..hideCurrentMaterialBanner()
                                        ..showMaterialBanner(materialBanner); */

                             /*         Map<String,String> dataToSave={
                                        'useremail':'Banele Mgwevu',
                                        'bucketURLCV':'www.get.com'

                                      };
                                       FirebaseFirestore.instance.collection('userCv').add(dataToSave);

                                      print("usercv clicked");

                            */

                                      String imageUrl='https://firebasestorage.googleapis.com/v0/b/baneledi.appspot.com/o/files%2FADARSHA_HINDU_HOTEL.pdf%2Ffile?alt=media&token=3469c8ec-90ae-4f8d-84ff-c34a5a78a2fc';




                                       // The argument type 'Future<Uin8List> can't be assigned to parameter type <List<int>



                                      if (!kIsWeb) {
                                        if (Platform.isIOS ||
                                            Platform.isAndroid ||
                                            Platform.isMacOS) {
                                          bool status = await Permission.storage.isGranted;

                                          if (!status) await Permission.storage.request();
                                        }
                                      }


                                        late final uri;
                                        String cvUrl;

                                        late String fName;
                                        final querySnapshot = await FirebaseFirestore.instance
                                            .collection('userCv')
                                            .limit(10)
                                            .where('useremail', isEqualTo: 'banelmgwevu@outlook.com')  //getting the email
                                            .get();

                                        for (var doc in querySnapshot.docs) {
                                          // Getting data directly

                                          fName = doc.get('fileName');
                                          cvUrl=doc.get('bucketURLCV');//getting the pdfurl
                                          print(fName +' o--polojijiji');
                                         final uri = Uri.parse(cvUrl); //converting string to uri,

                                         /* Reference ref = FirebaseStorage.instance
                                              .ref('files')
                                              .child('files/$fName');

                                         */

                                          final ref = FirebaseStorage.instance.refFromURL(
                                              "https://firebasestorage.googleapis.com/v0/b/baneledi.appspot.com/o/files%2FAccommodation.pdf%2Ffile?alt=media&token=cbb606e9-cbb6-4293-a1b7-d125fa646760");
                                          final url= await ref.getDownloadURL();
                                          final bytr= await ref.getData();

                                          print(url);
                                          final dir = await getApplicationDocumentsDirectory();
                                          final file = File('${dir.path}/${ref.name}');

                                          await ref.writeToFile(file);
                                          final tempDir = await getTemporaryDirectory();
                                          final path = '${tempDir.path}/${ref.name}';


                                          print(path);
                                          print(path);


                                          //      if (status2.isGranted) {
                                                try {
                                                  await Dio().download(url, path);
                                                  print('works bro');
                                                  print(file);
                                                  print(path);
                                                } catch (e) {
                                                  print(e);
                                                  print('error bro');
                                                }
                                      //        }

                                          final granted = await CRFileSaver.requestWriteExternalStoragePermission();

                                          log('requestWriteExternalStoragePermission: $granted');

                                          if(url.contains('.pdf')){
                                            String pathz = await FileSaver.instance.saveFile(fName, bytr!, 'pdf');
                                            await File('/storage/emulated/0/Android/data/com.example.untitled1/files').rename('/storage/emulated/0/DCIM');
                                            print(pathz);
                                          }



                                        }



                                      /*            final querySnapshot = await FirebaseFirestore.instance
                                          .collection('userCv')
                                          .limit(10)
                                          .where('name', isEqualTo: 'Banele Mgwevuz')
                                          .get();

                                      for (var doc in querySnapshot.docs) {
                                        // Getting data directly
                                        String name = doc.get('bucketURLCV');
                                        print(name);


                                        // Getting data from map
                                   //     Map<String, dynamic> data = doc.data();
                                  //      int age = data['age'];
                                      }
                        */
                                    },
                                  ), */
                                ],
                              ),
                              contentPadding: const EdgeInsets.only(left: 20),


                              hintText: "Say Hi...",
                              hintStyle: const TextStyle(color: Colors.black26),
                              border: InputBorder.none,
                            ),
                            style: const TextStyle(
                                fontSize: 16, color: Colors.black),
                            onChanged: (value) {},
                          ),
                        ),
                      ),


                    ),
                  )
                ],
              ),
              trailing: CircleAvatar(
                radius: 25,
                backgroundColor: const Color(0xff0d1b4b),

                child: IconButton(
                  icon: const Icon(

                    Icons.send,
                    color: Colors.white,
                  ),
                  onPressed: () {
                    if (messageInsert.text.isEmpty) {

                    } else {
                      setState(() {
                        messsages.insert(
                            0, {"data": 1, "message": messageInsert.text});  //This is the users text msgs

                        // this is where you get the first email and second email using regex
                      });
                      response(messageInsert.text);

                      if(isEmail(messageInsert.text)) {
                        if (email1.isEmpty) {

                          email1=messageInsert.text;


                          messageInsert.clear();
                        }else{
                          email2=messageInsert.text;

                          messageInsert.clear();

                        }
                      }


                      messageInsert.clear();
                    }
                    FocusScopeNode currentFocus = FocusScope.of(context);
                    if (!currentFocus.hasPrimaryFocus) {
                      currentFocus.unfocus();
                    }
                  },
                ),

              ),
            ),
            const SizedBox(
              height: 15.0,
            )

          ],
        ),
      ),
    );

  }

  Future cvFromGallery() async {

    FilePickerResult? result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: [ 'pdf', 'doc'],
    );

    setState(() {
      if(result != null) {
        PlatformFile file = result.files.first;



        String a= file.path as String; // ok this tricky converting future string? to string
        final uri = Uri.parse(a); //converting string to uri,
        _cv = File.fromUri(uri); //converting uri to file



        uploadFile();

      } else {
        // User canceled the picker
      }
    });

  }
  Future uploadFile() async { //T
    if (_cv == null) return;
    final fileName = basename(_cv!.path);
    final destination = 'files/$fileName';
    try {

      final ref = firebase_storage.FirebaseStorage.instance
          .ref(destination)
          .child('file/');
      await ref.putFile(_cv!);
      String urlBucket = (await ref.getDownloadURL()).toString(); //This is url for that will be stored in the Db




      Map<String,String> dataToSave={
        'useremail':email1,
        'bucketURLCV':urlBucket,
        'fileName':fileName

      };
      FirebaseFirestore.instance.collection('userCv').add(dataToSave);




    } catch (e) {
      if (kDebugMode) {
        print('error occured');
      }
    }
  }
  /* Future hasCv(String usermail)async{

    if (!kIsWeb) {
      if (Platform.isIOS ||
          Platform.isAndroid ||
          Platform.isMacOS) {
        bool status = await Permission.storage.isGranted;

        if (!status) await Permission.storage.request();
      }
    }



    String cvUrl;

    final querySnapshot = await FirebaseFirestore.instance
        .collection('userCv')
        .limit(10)
        .where('useremail', isEqualTo: usermail)  //getting the email
        .get();

    for (var doc in querySnapshot.docs) {
      // Getting data directly

      cvUrl=doc.get('bucketURLCV');//getting the pd furl

//converting string to uri,

      /* Reference ref = FirebaseStorage.instance
                                                .ref('files')
                                                .child('files/$fName');

                                           */

      final ref = FirebaseStorage.instance.refFromURL(cvUrl);
      final url= await ref.getDownloadURL();


      final dir = await getApplicationDocumentsDirectory();
      final file = File('${dir.path}/${ref.name}');

      await ref.writeToFile(file);
      final tempDir = await getTemporaryDirectory();
      final path = '${tempDir.path}/${ref.name}';





      //      if (status2.isGranted) {
      try {
        await Dio().download(url, path);

      } catch (e) {
        if (kDebugMode) {
          print(e);
        }

      }
      //        }

      final granted = await CRFileSaver.requestWriteExternalStoragePermission();

      log('requestWriteExternalStoragePermission: $granted');

      if(url.contains('.pdf')){
      //  await File('/storage/emulated/0/Android/data/com.example.untitled1/files').rename('/storage/emulated/0/DCIM');


      }



    }



  }

*/

  //for better one i have use the bubble package check out the pubspec.yaml
  Widget bottomIcons() {



    return SizedBox(
      height: 280,

      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 20),
        child: Column(
          children: [
            Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  IconButton(
                    icon: const Icon(
                      Icons.rocket,
                    ),

                    onPressed: () async {
                      cvFromGallery();

                    },

                  ),

                  const SizedBox(width: 40
                  ),
                ]
            ),
          ],
        ),
      ),
    );
  }


  Widget chat(String message, int data) {
    return Container(
      padding: const EdgeInsets.only(left: 20, right: 20),
      child: Row(
        mainAxisAlignment:
        data == 1 ? MainAxisAlignment.end : MainAxisAlignment.start,
        children: [
          data == 0
              ? const SizedBox (
            height: 60,
            width: 60,
            child: CircleAvatar(
              backgroundImage: AssetImage("assets/robot.jpg"),
            ),
          )


              : Container(),
          Padding(
            padding: const EdgeInsets.all(10.0),
            child: Bubble(
                radius: const Radius.circular(15.0), //sender bubble color
                color: data == 0
                    ? const Color.fromRGBO(
                    255, 255, 237, 2) //reciever bubble color
                    : const Color.fromRGBO(255, 255, 237, 2),
                elevation: 0.0,
                child: Padding(
                  padding: const EdgeInsets.all(2.0),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: <Widget>[
                      const SizedBox(
                        width: 10.0,
                      ),

                      Flexible(
                          child: Container(
                            constraints: const BoxConstraints(maxWidth: 170),
                            child: Text(
                              message,
                              style: const TextStyle(
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold),

                            ),
                          ))
                    ],
                  ),
                )),

          ),

          data == 1
              ? const SizedBox(
            height: 60,
            width: 60,
            child: CircleAvatar(
              backgroundImage: AssetImage("assets/avatar.png"), //sender user
            ),
          )
              : Container(),
        ],
      ),
    );

  }

  Widget chatMenu() {
    return GridView.builder(
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2),
        itemBuilder: (BuildContext context, int index) {
          return Card(
            child: Column(
              children: <Widget>[
                const SizedBox(
                  height: 20,


                ),
                Image.asset("robot/jpg")
              ],
            ),
          );
        });
  }



}





bool isEmail(String em) {

  String p = r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$';
  RegExp regExp = RegExp(p);
  return regExp.hasMatch(em);
}
int generateRandomNumber() {
  Random random = Random();
  int randomNumber = random.nextInt(90000) + 10000;

  return randomNumber;
}


