import 'dart:developer';
import 'dart:io';
import 'dart:typed_data';
import 'package:bubble/bubble.dart';
import 'package:dialog_flowtter/dialog_flowtter.dart';
import 'package:fiberchat/Screens/chat_bot/GPT/recruitment/cv_bot/cv_mailer.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:firebase_storage/firebase_storage.dart' as firebase_storage;
import 'package:path/path.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:path_provider/path_provider.dart';
import 'dart:math';
import 'package:email_validator/email_validator.dart';
import 'package:dio/dio.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:cr_file_saver/file_saver.dart';

import 'package:file_saver/file_saver.dart';
import 'package:cr_file_saver/generated/assets.dart';

import 'cv_mailer.dart';










class Asist extends StatefulWidget {
  const Asist({Key? key}) : super(key: key);



  @override
  _AsistState createState() => _AsistState();

}

class _AsistState extends State<Asist> {
  FirebaseAuth? auth;
  User? user;
  String? subscriptionPlanPrice, userId, documentId;
  bool? isSubscribe;
  bool? pdfBtn=true;

  final sendmailcv ini= sendmailcv();




  File? _cv;
  FilePickerResult? result;
  late String cv_path2;
  bool? getCV;   //if the getCv true then attachment becomes clickable the icon changes colors
  String pdfIntent="Click pdf button to upload your CV"; //dont temper with tis, unless u match with the response on dialogflow
  String uploadIntent="The email has been sent to your future employer"; //dont temper with tis unless you match the reponse
  String downloadIntent="Enter the email of the company you want to apply to. (FutureSoft@gmail.com)"; // dont temper with tis ''''''''''''''''''''''''''''''''''''''''''''''''
  late String email1='';
  late String email2='';
  final int sesId=generateRandomNumber();

  firebase_storage.FirebaseStorage storage =
      firebase_storage.FirebaseStorage.instance;

  FirebaseFirestore firestore = FirebaseFirestore.instance;


  void response(messageInsert) async {
    DialogAuthCredentials dialogAuthCredentials =
    await DialogAuthCredentials.fromFile('assets/services.json');

    final DialogFlowtter dialogFlowtter =
    DialogFlowtter(credentials: dialogAuthCredentials, sessionId: '$sesId');

    final QueryInput queryInput = QueryInput(
      text: TextInput(
        text: messageInsert,
        languageCode: 'en',
      ),
    );



    DetectIntentResponse response = await dialogFlowtter.detectIntent(
      queryInput: queryInput,
    );
    print(response.message?.text?.text?[0]);  // this is the chat-bot response
    if(response.message?.text?.text?[0]==pdfIntent){
      getCV=true;
      //  print(email1 + email2 +' SAMKANAA');
    }else if(response.message?.text?.text?[0]==uploadIntent){

      ini.uploadcv(email1, email2); //this purely for uploading cv

    }
    if(response.message?.text?.text?[0]==downloadIntent){ //this is downloading the file before uploading

      print('coodofdodijdoivdjovfhuihf \n dhvjkhvfhvfhufduvuivfziudhuvfiv \n uhvfhvifhfvihfvhvhvfuiuiuvhuhvihvif');
      ini.hasCv(email1);
    }

    print(response.message?.text?.text?[0]);

    setState(() {
      messsages
          .insert(0, {"data": 0, "message": response.message?.text?.text?[0]});
    });
  }

  final messageInsert = TextEditingController();
  List<Map> messsages = [];

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      backgroundColor: Theme
          .of(context)
          .primaryColor,
      appBar: AppBar(
        backgroundColor: const Color(0xff0d1b4b),
        titleSpacing: 0.5,
        title: Row(
          children: [

            const CircleAvatar(

              backgroundImage: AssetImage('assets/robot.jpg'),
            ),
            const Padding(
              padding: EdgeInsets.only(left: 8.0),

              child: Text(
                'Upload CV',

                style: TextStyle(
                  fontSize: 18,
                  height: 2.5,
                  //line height 200%, 1= 100%, were 0.9 = 90% of actual line height
                  color: Colors.white,
                  //font color

                  decorationThickness: 1.5, //decoration 'underline' thickness

                ),
              ),
            ),
          ],
        ),
        actions: [
          PopupMenuButton<String>(
            color: Colors.white,
            itemBuilder: (BuildContext context) {
              return [
                PopupMenuItem
                  (
                  onTap: () {showDialog(
                      context: context,builder: (context) {return Container(
                    child: AlertDialog(
                      title: Text("Info Coming soon!"),
                      actions: [
                        TextButton(onPressed: () {
                          Navigator.pop(context);
                        }, child: Text("OK"))
                      ],
                    ),
                  );}
                  ); },
                  value: "New group",
                  child: Text('Info'),
                ),
                PopupMenuItem(
                  onTap: () {showDialog(
                      context: context,builder: (context) {return Container(
                    child: AlertDialog(
                      title: Text("Call Coming soon!"),
                      actions: [
                        TextButton(onPressed: () {
                          Navigator.pop(context);
                        }, child: Text("OK"))
                      ],
                    ),
                  );}
                  ); },
                  value: "New group",
                  child: Text('Chat-bot Support'),
                ),
              ];
            },
          ),
          //IconButton(
          //icon: const Icon(Icons.more_vert),
          //onPressed: () {
          //print('Three Dot-Button Button');
          //}),
        ],
      ),

      body: SafeArea(

        child: Column(

          children: <Widget>[
            Flexible(
                child: ListView.builder(
                    reverse: true,
                    itemCount: messsages.length,
                    itemBuilder: (context, index) =>
                        chat(
                            messsages[index]["message"].toString(),
                            messsages[index]["data"]))
            ),
            const SizedBox(
              height: 10,

            ),

            ListTile(

              /*     leading: Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(250),
                ),
                child: IconButton(
                  onPressed: () {
                    print('ok');
                    showModalBottomSheet(context: context, builder: (builder)=>bottomIcons());
                  },
                  icon: const Icon(
                    Icons. attachment_outlined,
                    color: Colors.black,
                    size: 30,
                  ),
                ),
              ),  */

              title: Row(
                children: [

                  Expanded(
                    flex: 5,


                    child: Padding(
                      padding: const EdgeInsets.only(
                        bottom: 8,
                        right: 5,
                        left: 3,
                      ),

                      child: Container(
                        height: 40,
                        width: 2500,
                        //               color: Colors.orangeAccent,
                        decoration: const BoxDecoration(
                          borderRadius: BorderRadius.all(Radius.circular(100)),
                          color: Color.fromRGBO(220, 220, 220, 1),

                        ),
                        padding: const EdgeInsets.only(left: 2),

                        child: Center(
                          child: TextFormField(
                            controller: messageInsert,
                            onTap: () {
                              //        print("I'm here!!!");
                            },
                            textAlignVertical: TextAlignVertical.center,
                            keyboardType: TextInputType.multiline,
                            maxLines: null, // 5,
                            minLines: null, // 1,
                            expands: true,

                            decoration: InputDecoration(
                              /*                  prefixIcon: IconButton(
                                icon: const Icon(Icons.emoji_emotions),
                                onPressed: () {
                                  print(email1 +' email 1 emoji');
                                  print(email2 + ' email 2 emoji');

                                },
                              ), */
                              suffixIcon: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  IconButton(
                                      icon: const Icon(

                                        Icons.picture_as_pdf_outlined,),

                                      onPressed: () async {



                                        if(getCV==true) {

                                          cvFromGallery();

                                          if(ini.msgSentBanner==true){

                                            if(_cv!=null && email1.isNotEmpty && email2.isNotEmpty){

                                              const snackBar = SnackBar(
                                                  content: Text('The email has been sent'));

                                              ScaffoldMessenger.of(context).showSnackBar(snackBar);
                                            }



                                          }


                                        }else{}



//                                         onPressed: pdfBtn
//                                           ? () => cvFromGallery()
//                                           : null


                                      }



                                  ),


                                  /*      IconButton(
                                    icon: const Icon(Icons.camera_alt),
                                    onPressed: () async {
                   //                   ini.sendEmail(email1,email2);

                                  /*    final materialBanner = MaterialBanner(
                                        /// need to set following properties for best effect of awesome_snackbar_content
                                        elevation: 0,
                                        backgroundColor: Colors.transparent,
                                        forceActionsBelow: false,

                                        content: AwesomeSnackbarContent(
                                          title: 'Oh Hey!!',
                                          message:
                                          'The email has been sent to your prospective employer, Thank your using Softmeet Chatbot!',

                                          /// change contentType to ContentType.success, ContentType.warning or ContentType.help for variants
                                          contentType: ContentType.success,
                                          // to configure for material banner
                                          inMaterialBanner: true,
                                        ),
                                        actions: const [SizedBox.shrink()],
                                      );

                                      ScaffoldMessenger.of(context)
                                        ..hideCurrentMaterialBanner()
                                        ..showMaterialBanner(materialBanner); */

                             /*         Map<String,String> dataToSave={
                                        'useremail':'Banele Mgwevu',
                                        'bucketURLCV':'www.get.com'

                                      };
                                       FirebaseFirestore.instance.collection('userCv').add(dataToSave);

                                      print("usercv clicked");

                            */

                                      String imageUrl='https://firebasestorage.googleapis.com/v0/b/baneledi.appspot.com/o/files%2FADARSHA_HINDU_HOTEL.pdf%2Ffile?alt=media&token=3469c8ec-90ae-4f8d-84ff-c34a5a78a2fc';




                                       // The argument type 'Future<Uin8List> can't be assigned to parameter type <List<int>



                                      if (!kIsWeb) {
                                        if (Platform.isIOS ||
                                            Platform.isAndroid ||
                                            Platform.isMacOS) {
                                          bool status = await Permission.storage.isGranted;

                                          if (!status) await Permission.storage.request();
                                        }
                                      }


                                        late final uri;
                                        String cvUrl;

                                        late String fName;
                                        final querySnapshot = await FirebaseFirestore.instance
                                            .collection('userCv')
                                            .limit(10)
                                            .where('useremail', isEqualTo: 'banelmgwevu@outlook.com')  //getting the email
                                            .get();

                                        for (var doc in querySnapshot.docs) {
                                          // Getting data directly

                                          fName = doc.get('fileName');
                                          cvUrl=doc.get('bucketURLCV');//getting the pdfurl
                                          print(fName +' o--polojijiji');
                                         final uri = Uri.parse(cvUrl); //converting string to uri,

                                         /* Reference ref = FirebaseStorage.instance
                                              .ref('files')
                                              .child('files/$fName');

                                         */

                                          final ref = FirebaseStorage.instance.refFromURL(
                                              "https://firebasestorage.googleapis.com/v0/b/baneledi.appspot.com/o/files%2FAccommodation.pdf%2Ffile?alt=media&token=cbb606e9-cbb6-4293-a1b7-d125fa646760");
                                          final url= await ref.getDownloadURL();
                                          final bytr= await ref.getData();

                                          print(url);
                                          final dir = await getApplicationDocumentsDirectory();
                                          final file = File('${dir.path}/${ref.name}');

                                          await ref.writeToFile(file);
                                          final tempDir = await getTemporaryDirectory();
                                          final path = '${tempDir.path}/${ref.name}';


                                          print(path);
                                          print(path);


                                          //      if (status2.isGranted) {
                                                try {
                                                  await Dio().download(url, path);
                                                  print('works bro');
                                                  print(file);
                                                  print(path);
                                                } catch (e) {
                                                  print(e);
                                                  print('error bro');
                                                }
                                      //        }

                                          final granted = await CRFileSaver.requestWriteExternalStoragePermission();

                                          log('requestWriteExternalStoragePermission: $granted');

                                          if(url.contains('.pdf')){
                                            String pathz = await FileSaver.instance.saveFile(fName, bytr!, 'pdf');
                                            await File('/storage/emulated/0/Android/data/com.example.untitled1/files').rename('/storage/emulated/0/DCIM');
                                            print(pathz);
                                          }



                                        }



                                      /*            final querySnapshot = await FirebaseFirestore.instance
                                          .collection('userCv')
                                          .limit(10)
                                          .where('name', isEqualTo: 'Banele Mgwevuz')
                                          .get();

                                      for (var doc in querySnapshot.docs) {
                                        // Getting data directly
                                        String name = doc.get('bucketURLCV');
                                        print(name);


                                        // Getting data from map
                                   //     Map<String, dynamic> data = doc.data();
                                  //      int age = data['age'];
                                      }
                        */
                                    },
                                  ), */
                                ],
                              ),
                              contentPadding: const EdgeInsets.only(left: 20),


                              hintText: "Say Hi...",
                              hintStyle: const TextStyle(color: Colors.black26),
                              border: InputBorder.none,
                            ),
                            style: const TextStyle(
                                fontSize: 16, color: Colors.black),
                            onChanged: (value) {},
                          ),
                        ),
                      ),


                    ),
                  )
                ],
              ),
              trailing: CircleAvatar(
                radius: 25,
                backgroundColor: const Color(0xff0d1b4b),

                child: IconButton(
                  icon: const Icon(

                    Icons.send,
                    color: Colors.white,
                  ),
                  onPressed: () {
                    if (messageInsert.text.isEmpty) {
                      print("empty message");
                    } else {
                      setState(() {
                        messsages.insert(
                            0, {"data": 1, "message": messageInsert.text});  //This is the users text msgs

                        // this is where you get the first email and second email using regex
                      });
                      response(messageInsert.text);

                      // if(isEmail(messageInsert.text)) {
                      //   if (email1.isEmpty) {
                      //
                      //     email1=messageInsert.text;
                      //     print(email1 +' email 1 before');
                      //     print(email2 + ' email 2 before');
                      //     messageInsert.clear();
                      //   }else{
                      //     email2=messageInsert.text;
                      //     print(email1 +' email 1 after');
                      //     print(email2 + ' email 2 after');
                      //     messageInsert.clear();
                      //
                      //   }
                      // }

                      if(ini.isEmail(messageInsert.text)) {
                        if (email1.isEmpty) {

                          email1=messageInsert.text;
                          print(email1 +' email 1 before');
                          print(email2 + ' email 2 before');
                          messageInsert.clear();
                        }else{
                          email2=messageInsert.text;
                          print(email1 +' email 1 after');
                          print(email2 + ' email 2 after');
                          messageInsert.clear();

                        }
                      }


                      messageInsert.clear();
                    }
                    FocusScopeNode currentFocus = FocusScope.of(context);
                    if (!currentFocus.hasPrimaryFocus) {
                      currentFocus.unfocus();
                    }
                  },
                ),

              ),
            ),
            const SizedBox(
              height: 15.0,
            )

          ],
        ),
      ),
    );

  }

  Future cvFromGallery() async {

    FilePickerResult? result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: [ 'pdf', 'doc'],
    );

    setState(() {
      if(result != null) {
        PlatformFile file = result.files.first;

        //   _cv = File(FilePickerResult.path);
        print(file.name);
        print(file.size);
        print(file.extension);
        print(file.path);
        print(email1 + email2 + ' **#=30303045*&&^%###@');
        print("Thiis is email1 ghhyhyjyyjuju 8888766676S $email1");
        print("Thiis is email1 ghhyhyjyyjuju 888888888 $email2");

        String a= file.path as String; // ok this tricky converting future string? to string
        final uri = Uri.parse(a); //converting string to uri,
        _cv = File.fromUri(uri); //converting uri to file

        ini.sendEmail(email1, email2, _cv!);  //send email

        uploadFile();
        print(_cv);
      } else {
        // User canceled the picker
      }
    });

  }
  Future uploadFile() async { //T
    if (_cv == null) return;
    final fileName = basename(_cv!.path);
    final destination = 'files/$fileName';
    try {

      final ref = firebase_storage.FirebaseStorage.instance
          .ref(destination)
          .child('file/');
      await ref.putFile(_cv!);
      String urlBucket = (await ref.getDownloadURL()).toString(); //This is url for that will be stored in the Db
      print(urlBucket + ' This is the url bucket link ');
      print(fileName);
      print(destination);



      Map<String,String> dataToSave={
        'useremail':email1,
        'bucketURLCV':urlBucket,
        'fileName':fileName

      };
      FirebaseFirestore.instance.collection('userCv').add(dataToSave);

      print("usercv clicked");



    } catch (e) {
      print('error occured');
    }
  }
/*  Future hasCv(String usermail)async{

    if (!kIsWeb) {
      if (Platform.isIOS ||
          Platform.isAndroid ||
          Platform.isMacOS) {
        bool status = await Permission.storage.isGranted;

        if (!status) await Permission.storage.request();
      }
    }



    String cvUrl;

    late String fName;
    final querySnapshot = await FirebaseFirestore.instance
        .collection('userCv')
        .limit(10)
        .where('useremail', isEqualTo: usermail)  //getting the email
        .get();

    for (var doc in querySnapshot.docs) {
      // Getting data directly

      fName = doc.get('fileName');
      cvUrl=doc.get('bucketURLCV');//getting the pdfurl
      print(fName +' o--polojijiji');
//converting string to uri,

      /* Reference ref = FirebaseStorage.instance
                                                .ref('files')
                                                .child('files/$fName');

                                           */

      final ref = FirebaseStorage.instance.refFromURL(cvUrl);
      final url= await ref.getDownloadURL();
      final bytr= await ref.getData();

      print(url);
      final dir = await getApplicationDocumentsDirectory();
      final file = File('${dir.path}/${ref.name}');

      await ref.writeToFile(file);
      final tempDir = await getTemporaryDirectory();
      final path = '${tempDir.path}/${ref.name}';


      print(path);
      print(path);


      //      if (status2.isGranted) {
      try {
        await Dio().download(url, path);
        print('works bro');
        print(file);
        print(path);
      } catch (e) {
        print(e);
        print('error bro');
      }
      //        }

      final granted = await CRFileSaver.requestWriteExternalStoragePermission();

      log('requestWriteExternalStoragePermission: $granted');

      if(url.contains('.pdf')){
        String pathz = await FileSaver.instance.saveFile(fName, bytr!, 'pdf');
      //  await File('/storage/emulated/0/Android/data/com.example.untitled1/files').rename('/storage/emulated/0/DCIM');
        cv_path2=pathz;
        print(pathz);
      }



    }



  }

*/

  //for better one i have use the bubble package check out the pubspec.yaml
  Widget bottomIcons() {



    return SizedBox(
      height: 280,

      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 20),
        child: Column(
          children: [
            Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  IconButton(
                    icon: const Icon(
                      Icons.rocket,
                    ),

                    onPressed: () async {
                      cvFromGallery();

                    },

                  ),

                  const SizedBox(width: 40
                  ),
                ]
            ),
          ],
        ),
      ),
    );
  }


  Widget chat(String message, int data) {
    return Container(
      padding: const EdgeInsets.only(left: 20, right: 20),
      child: Row(
        mainAxisAlignment:
        data == 1 ? MainAxisAlignment.end : MainAxisAlignment.start,
        children: [
          data == 0
              ? const SizedBox (
            height: 60,
            width: 60,
            child: CircleAvatar(
              backgroundImage: AssetImage("assets/robot.jpg"),
            ),
          )


              : Container(),
          Padding(
            padding: const EdgeInsets.all(10.0),
            child: Bubble(
                radius: const Radius.circular(15.0), //sender bubble color
                color: data == 0
                    ? const Color.fromRGBO(
                    255, 255, 237, 2) //reciever bubble color
                    : const Color.fromRGBO(255, 255, 237, 2),
                elevation: 0.0,
                child: Padding(
                  padding: const EdgeInsets.all(2.0),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: <Widget>[
                      const SizedBox(
                        width: 10.0,
                      ),

                      Flexible(
                          child: Container(
                            constraints: const BoxConstraints(maxWidth: 170),
                            child: Text(
                              message,
                              style: const TextStyle(
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold),

                            ),
                          ))
                    ],
                  ),
                )),

          ),

          data == 1
              ? const SizedBox(
            height: 60,
            width: 60,
            child: CircleAvatar(
              backgroundImage: AssetImage("assets/avatar.png"), //sender user
            ),
          )
              : Container(),
        ],
      ),
    );

  }

  Widget chatMenu() {
    return GridView.builder(
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2),
        itemBuilder: (BuildContext context, int index) {
          return Card(
            child: Column(
              children: <Widget>[
                const SizedBox(
                  height: 20,


                ),
                Image.asset("robot/jpg")
              ],
            ),
          );
        });
  }


}



// bool isEmail(String em) {
//
//   String p = r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$';
//   //String p = r'^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$';
//   //String p = r'^(?=.{1,254}$)[a-zA-Z0-9._%+-]+@(?!.*\.\.)[a-zA-Z0-9.-]+\.[a-zA-Z]{2,63}$';
//   //String p = r'^[a-zA-Z0-9.!#$%&\*+\/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$';
//   //String p = r'^(?=.{1,254}$)(?=.{1,64}@.{1,255}$)(?=[^@]{1,64}@(?:[^@]{1,63}\.){1,125}[A-Za-z]{2,63}$)[a-zA-Z0-9!#$%&*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&*+/=?^_`{|}~-]+)*@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$';
//   RegExp regExp = RegExp(p);
//   return regExp.hasMatch(em);
//
// }

int generateRandomNumber() {
  Random random = Random();
  int randomNumber = random.nextInt(90000) + 10000;

  return randomNumber;
}


