import 'dart:developer';
import 'dart:io';

import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/foundation.dart';
import 'package:mailer/mailer.dart';
import 'package:mailer/smtp_server.dart';
import 'package:cloud_firestore/cloud_firestore.dart';


import 'package:dio/dio.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:cr_file_saver/file_saver.dart';

import 'package:file_saver/file_saver.dart';

import 'package:path_provider/path_provider.dart';






class sendmailcv {



  bool? msgSentBanner;
  late String cv_path2;
  late File cv2;

  bool isEmail(String em) {

  String p = r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$';
  //String p = r'^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$';
  //String p = r'^(?=.{1,254}$)[a-zA-Z0-9._%+-]+@(?!.*\.\.)[a-zA-Z0-9.-]+\.[a-zA-Z]{2,63}$';
  //String p = r'^[a-zA-Z0-9.!#$%&\*+\/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$';
  //String p = r'^(?=.{1,254}$)(?=.{1,64}@.{1,255}$)(?=[^@]{1,64}@(?:[^@]{1,63}\.){1,125}[A-Za-z]{2,63}$)[a-zA-Z0-9!#$%&*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&*+/=?^_`{|}~-]+)*@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$';
  RegExp regExp = RegExp(p);
  return regExp.hasMatch(em);

}


  void sendEmail(String email1,String email2, File cv) async {
    String username = 'thato@softmeet.co.za';
    String password = 'SirAlton@99';


    final smtpServer = SmtpServer(
      'mail.softmeet.co.za',
      port: 465,
      ssl: true,
      ignoreBadCertificate: true,
      allowInsecure: true,
      username: username,
      password: password,
    );

    print('This is ur email :'+ email1);
    // Use the SmtpServer class 2 configure an SMTP server:
    // final smtpServer = SmtpServer('smtp.domain.com');
    // See the named arguments of SmtpServer for further configuration
    // options.

    // Create our message.
    final message = Message()
      ..from = Address(username, 'Softmeet Job Application Bot')
      ..ccRecipients.addAll([email1])
      ..subject = 'The Email has been sent to the prospective employer'
      ..text = 'Application for the available job post'
      ..html = '<h1>Confirmation Email</h1>\n<p>Dear Mr./Ms </p><br><br>Your email has been sent. Thank you for using our service.<br><br>Kind Regards';


    try {
      final sendReport = await send(message, smtpServer);
      print('Message sent: ' + sendReport.toString());
      msgSentBanner=true;


    } on MailerException catch (e) {
      print('Message not sent.');

      for (var p in e.problems) {
        print('Problem: ${p.code}: ${p.msg}');
      }
    }
    // DONE


    // Let's send another message using a slightly different syntax:
    //
    // Addresses without a name part can be set directly.
    // For instance `..recipients.add('destination@example.com')`
    // If you want to display a name part you have to create an
    // Address object: `new Address('destination@example.com', 'Display name part')`
    // Creating and adding an Address object without a name part
    // `new Address('destination@example.com')` is equivalent to
    // adding the mail address as `String`.
    final equivalentMessage = Message()
      ..from = Address(username, 'SoftMeet Application Bot')
      ..recipients.add(Address(email1))
      ..ccRecipients.addAll(
          [Address(email2)])
      ..subject = 'Application For Job/Post'
      ..text = 'Application for the available vacancy'
      ..html = '<p>Dear Mr./Ms </p><br><br>Please find my CV attached for the role [Job Title]. If there is any additional information you need, please let me know. Thank you very much for your consideration. I hope to hear from you soon.<br>Kind Regards'
      ..attachments.add(FileAttachment(cv));


    final sendReport2 = await send(equivalentMessage, smtpServer);

    // Sending multiple messages with the same connection
    //
    // Create a smtp client that will persist the connection
    var connection = PersistentConnection(smtpServer);

    // Send the first message
    await connection.send(message);

    // send the equivalent message
    await connection.send(equivalentMessage);

    // close the connection
    await connection.close();
  }

  void uploadcv(String email1,String email2) async {


    File cv; //CV From Cloud Firestoree
    final querySnapshot = await FirebaseFirestore.instance
        .collection('userCv')
        .limit(10)
        .where('useremail', isEqualTo: email1)  //getting the email
        .get();

    for (var doc in querySnapshot.docs) {
      // Getting data directly
      String cvUrl = doc.get('bucketURLCV');     //getting the pdfurl
      print(cvUrl);
    }

    String username = 'thato@softmeet.co.za';
    String password = 'SirAlton@99';


    final smtpServer = SmtpServer(
      'mail.softmeet.co.za',
      port: 465,
      ssl: true,
      ignoreBadCertificate: true,
      allowInsecure: true,
      username: username,
      password: password,
    );

    print('This is ur email :'+ email1);
    // Use the SmtpServer class to configure an SMTP server:
    // final smtpServer = SmtpServer('smtp.domain.com');
    // See the named arguments of SmtpServer for further configuration
    // options.

    // Create our message.
    final message = Message()
      ..from = Address(username, 'SoftMeet Application Bot')
      ..recipients.add(email2)
      ..ccRecipients.addAll([email1])

      ..subject = 'Application For Job/Post'
      ..text = 'Application for the available job post'
      ..html = '<p>Dear Mr./Ms </p><br><br>This an application for the available job post. My CV is attached on the email.<br><br>Kind Regards'
      ..attachments.add(FileAttachment(File(cv_path2)));

    try {
      final sendReport = await send(message, smtpServer);
      print('Message sent: ' + sendReport.toString());
      msgSentBanner=true;


    } on MailerException catch (e) {
      print('Message not sent.');

      for (var p in e.problems) {
        print('Problem: ${p.code}: ${p.msg}');
      }
    }
    // DONE
    print("Thiis is email1 ghhyhyjyyjuju $email1");
    print("Thiis is email1 ghhyhyjyyjuju $email2");

    // Let's send another message using a slightly different syntax:
    //
    // Addresses without a name part can be set directly.
    // For instance `..recipients.add('destination@example.com')`
    // If you want to display a name part you have to create an
    // Address object: `new Address('destination@example.com', 'Display name part')`
    // Creating and adding an Address object without a name part
    // `new Address('destination@example.com')` is equivalent to
    // adding the mail address as `String`.
    final equivalentMessage = Message()
      ..from = Address(username, 'SoftMeet Application bot 😀')
      ..recipients.add(Address(email1))
      ..ccRecipients.addAll(
          [Address(email2)])

      ..subject = 'SoftMeet CV Application Bot'
      ..text = 'Application for the available job post'
      ..html = '<h1>Test</h1>\n<p>Dear Mr./Ms </p><br><br>This an application for the available job post. My CV is attached on the email.<br><br>Kind Regards'
      ..attachments.add(FileAttachment(cv2));


    final sendReport2 = await send(equivalentMessage, smtpServer);

    // Sending multiple messages with the same connection
    //
    // Create a smtp client that will persist the connection
    var connection = PersistentConnection(smtpServer);

    // Send the first message
    await connection.send(message);

    // send the equivalent message
    await connection.send(equivalentMessage);

    // close the connection
    await connection.close();


  }
  Future hasCv(String usermail)async{

    if (!kIsWeb) {
      if (Platform.isIOS ||
          Platform.isAndroid ||
          Platform.isMacOS) {
        bool status = await Permission.storage.isGranted;

        if (!status) await Permission.storage.request();
      }
    }



    String cvUrl;

    late String fName;
    final querySnapshot = await FirebaseFirestore.instance
        .collection('userCv')
        .limit(10)
        .where('useremail', isEqualTo: usermail)  //getting the email
        .get();

    for (var doc in querySnapshot.docs) {
      // Getting data directly

      fName = doc.get('fileName'); //G
      cvUrl=doc.get('bucketURLCV');//getting the pdfurl

      final uri = Uri.parse(cvUrl); //converting string to uri,

      /* Reference ref = FirebaseStorage.instance
                                                .ref('files')
                                                .child('files/$fName');

                                           */

      final ref = FirebaseStorage.instance.refFromURL(cvUrl);
      final url= await ref.getDownloadURL();
      final bytr= await ref.getData();

      print(url);
      final dir = await getApplicationDocumentsDirectory();
      final file = File('${dir.path}/${ref.name}');

      await ref.writeToFile(file);
      final tempDir = await getTemporaryDirectory();
      final path = '${tempDir.path}/${ref.name}';


      print(path);
      print(path);


      //      if (status2.isGranted) {
      try {
        await Dio().download(url, path);
        print('works bro');
        print(file);
        print(path);
      } catch (e) {
        print(e);
        print('error bro');
      }
      //        }

      final granted = await CRFileSaver.requestWriteExternalStoragePermission();

      log('requestWriteExternalStoragePermission: $granted');

      if(url.contains('.pdf')){
        String pathz = await FileSaver.instance.saveFile(fName, bytr!, 'pdf');
        //  await File('/storage/emulated/0/Android/data/com.example.untitled1/files').rename('/storage/emulated/0/DCIM');
        cv_path2=pathz;
        cv2=File(pathz);
        print(pathz);
      }



    }



  }



}
